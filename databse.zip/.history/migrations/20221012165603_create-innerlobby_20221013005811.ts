import { Knex } from "knex";


export async function up(knex: Knex) {
    const hasTable = await knex.schema.hasTable("innerlobby");
    if (!hasTable) {
        await knex.schema.createTable("innerlobby", (table) => {
            table.increments();
            table.string("name");
            table.string("content");
        });
    }
}

export async function down(knex: Knex) {
    await knex.schema.dropTableIfExists("innerlobby");
}


