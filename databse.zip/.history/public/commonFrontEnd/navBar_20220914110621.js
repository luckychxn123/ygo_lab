// const { it } = require("node:test")

document.querySelector('#header').innerHTML = /*HTML */
    `
            <section class="menu-bar">
            <div class="topnav">
            <div id="LHS">
                <a class="active" href="../index/index.html">Lobby</a>
                <a href="../privateRoom/privateRoom.html">Private Room</a>
                <a href="../deckBuilding/deckBuilding.html">Deck Building</a>
                <a href="../market/market.html">Market</a>
            </div>
    
            <div class="RHS">
                <div id="user">
                    Welcome,
                </div>
                <a id="logOut" href="/logout">
                    Logout
                </a>
            </div>
        </div>

            </section>`

async function getUserProfile() {
    let res = await fetch('/me')
    if (!res.ok) {
        console.log('get user fail')
        return
    }

    let user = await res.json()
    // console.log('user data = ', user)
    gotUsername = user.data.username
    let userDiv = document.querySelector('#user')
    userDiv.innerHTML += gotUsername + "!"

}


getUserProfile()