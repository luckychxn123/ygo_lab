let deckZoneElem = document.querySelector(".deck-zone")
let inventoryZoneElem = document.querySelector(".inventory-zone")
let deckMenuElem = document.querySelector(".deck-menu")
let deckNameElem = document.querySelector(".deck-name")
let editBtn = document.querySelector(".edit-btn")
let createDeckBtn = document.querySelector(".create-deck-btn")
let saveBtn = document.querySelector(".save-btn")


loadDecks()

let inventoryCards = []
let deckCards = []



// Load the Decks (from database)
async function loadDecks() {
    const res = await fetch('/deck/loadDecks', {
        method: 'GET'
    })
    if (res.ok) {
        let dbDecks = await res.json()
        for (let dbDeck of dbDecks) {
            deckMenuElem.innerHTML = deckMenuElem.innerHTML + /*HTML*/`
            <li><button class="dropdown-item user-deck" id="deck-${dbDeck.id}" type="button">${dbDeck.deck_name}</button></li>
            `
        }
        let userDeckElems = document.querySelectorAll(".user-deck")
        for (let userDeckElem of userDeckElems) {
            userDeckElem.addEventListener('click', async () => {
                let deckIdToBeLoaded = userDeckElem.id.slice(5)
                console.log("deckIdToBeLoaded: ", deckIdToBeLoaded)

                deckNameElem.innerHTML = userDeckElem.innerHTML

                deckCards = []
                inventoryCards = []

                await loadDeckCards(deckIdToBeLoaded)
                await manipulateCards()
                console.log("load deck completed")
            })
        }

    } else {
        console.log("load decks fail")
    }
}


// Load the Cards (from database)
async function loadDeckCards(deckIdToBeLoaded) {
    let currentDeckCardQtyList = []
    const res = await fetch(`/deck/loadDeckCards/${deckIdToBeLoaded}`, {
        method: 'GET'
    })

    if (res.ok) {
        let dbCards = await res.json()

        deckZoneElem.innerHTML = ""

        for (let dbCard of dbCards) {
            deckCards.push(dbCard)
        }


        for (let deckCard of deckCards) {
            deckZoneElem.innerHTML = deckZoneElem.innerHTML + /*HTML*/`
                <div class="card my-deck my-deck-card" id="card-${deckCard.card_id}">
                    <img src="/cardAssets/${deckCard.image}" class="card-image">
                    <div class="remove-card my-deck hide-btn" id="card-${deckCard.card_id}">
                        <div>-</div>
                    </div>
                    <div class="card-qty my-deck" id="card-${deckCard.card_id}">${deckCard.card_in_deck_quantity}</div>
                </div>
            `

        }



        for (let deckCard of deckCards) {
            let cardId = deckCard.card_id
            let qtyInDeck = deckCard.card_in_deck_quantity
            currentDeckCardQtyList.push({
                cardId: cardId,
                qtyInDeck: qtyInDeck
            })
        }

        await loadInventoryCards(deckCards)

    } else {
        console.log("load cards fail")
    }

}


async function loadInventoryCards(deckCards) {
    console.log("current deck card quantity:", deckCards)

    const res = await fetch("/deck/loadInventoryCards", {
        method: 'GET'
    })

    if (res.ok) {
        let dbCards = await res.json()
        // let inventoryCards = []

        inventoryZoneElem.innerHTML = ""
        for (let dbCard of dbCards) {
            inventoryCards.push(dbCard)
        }
        console.log("inventory cards array: ", inventoryCards)


        for (let inventoryCard of inventoryCards) {
            let currentInventoryQty = 3;

            for (let deckCard of deckCards) {
                if (deckCard.card_id == inventoryCard.id) {
                    currentInventoryQty = parseInt(inventoryCard.quantity) - parseInt(deckCard.card_in_deck_quantity)
                    break
                }
                currentInventoryQty = parseInt(inventoryCard.quantity)

            }

            inventoryZoneElem.innerHTML = inventoryZoneElem.innerHTML + /*HTML*/`
                <div class="card my-inventory my-inventory-card" id="card-${inventoryCard.id}">
                    <img src="/cardAssets/${inventoryCard.image}" class="card-image">
                    <div class="add-card my-inventory hide-btn" id="card-${inventoryCard.id}">
                        <div>+</div>
                    </div>
                    <div class="card-qty my-inventory" id="card-${inventoryCard.id}">${currentInventoryQty}</div>
                </div>
            `

        }
    }
}

// Edit the deck cards
async function manipulateCards() {

    let addCardBtns = document.querySelectorAll(".add-card")
    let removeCardBtns = document.querySelectorAll(".remove-card")
    let cardQtyElems = document.querySelectorAll(".card-qty")
    let myDeckCardElems = document.querySelectorAll(".my-deck-card")

    // Enter and Leave Edit Mode
    editBtn.addEventListener("click", () => {
        console.log("deckCards: ", deckCards)

        for (let addCardBtn of addCardBtns) {
            addCardBtn.classList.toggle("hide-btn")
        }
        for (let removeCardBtn of removeCardBtns) {
            removeCardBtn.classList.toggle("hide-btn")
        }

    });


    // Add Cards to My Deck
    for (let addCardBtn of addCardBtns) {
        addCardBtn.addEventListener("click", () => {

            // handle the quantity changes in My Inventory
            for (let cardQtyElem of cardQtyElems) {
                if (cardQtyElem.id == addCardBtn.id && cardQtyElem.classList.contains("my-inventory")) {

                    let inventoryCardQty = parseInt(cardQtyElem.innerHTML)

                    if (inventoryCardQty != 0) {
                        inventoryCardQty -= 1
                        cardQtyElem.innerHTML = inventoryCardQty
                    }
                    // 點擊inventory卡的加號的時候，判斷在deck裡有沒有
                    let isExistedInDeck = false
                    for (let deckCard of deckCards) {
                        if (cardQtyElem.id.slice(5) == deckCard.card_id) {
                            isExistedInDeck = true
                            break
                        }
                        else {
                            isExistedInDeck = false

                        }
                    }
                    console.log(isExistedInDeck)
                    // 假如deck裡沒有，就插入一張卡
                    if (isExistedInDeck == false) {
                        for (let inventoryCard of inventoryCards) {
                            if (cardQtyElem.id.slice(5) == inventoryCard.card_id) {

                                deckZoneElem.innerHTML = deckZoneElem.innerHTML + /*HTML*/`
                                    <div class="card my-deck my-deck-card" id="card-${inventoryCard.card_id}">
                                        <img src="/cardAssets/${inventoryCard.image}" class="card-image">
                                        <div class="remove-card my-deck" id="card-${inventoryCard.card_id}">
                                            <div>-</div>
                                        </div>
                                        <div class="card-qty my-deck" id="card-${inventoryCard.card_id}">0</div>
                                    </div>
                                `
                                deckCards.push(inventoryCard)
                                cardQtyElems = document.querySelectorAll(".card-qty")

                                // Remove Qty Btn 補返 event listeners
                                let newRemoveCardBtns = document.querySelectorAll(".remove-card")
                                for (let newRemoveCardBtn of newRemoveCardBtns) {
                                    newRemoveCardBtn.addEventListener("click", () => {


                                        for (let cardQtyElem of cardQtyElems) {
                                            if (cardQtyElem.id == newRemoveCardBtn.id && cardQtyElem.classList.contains("my-inventory")) {

                                                let inventoryCardQty = parseInt(cardQtyElem.innerHTML)

                                                if (inventoryCardQty != 3) {
                                                    inventoryCardQty += 1
                                                    cardQtyElem.innerHTML = inventoryCardQty
                                                }
                                            }
                                        }

                                        for (let cardQtyElem of cardQtyElems) {
                                            if (cardQtyElem.id == newRemoveCardBtn.id && cardQtyElem.classList.contains("my-deck")) {
                                                let deckCardQty = parseInt(cardQtyElem.innerHTML)

                                                if (deckCardQty != 0) {
                                                    deckCardQty -= 1
                                                    cardQtyElem.innerHTML = deckCardQty
                                                }

                                                if (deckCardQty == 0) {
                                                    for (let myDeckCardElem of myDeckCardElems) {
                                                        if (myDeckCardElem.id == newRemoveCardBtn.id)
                                                            // myDeckCardElem.style.display = "none"
                                                            myDeckCardElem.style.opacity = "30%"
                                                    }
                                                }

                                            }

                                        }

                                    })
                                }

                            }
                        }
                    }
                }
            }

            console.log({ inventoryCards })
            console.log({ deckCards })

            for (let cardQtyElem of cardQtyElems) {
                if (cardQtyElem.id == addCardBtn.id && cardQtyElem.classList.contains("my-deck")) {

                    let deckCardQty = parseInt(cardQtyElem.innerHTML)

                    if (deckCardQty != 3) {
                        deckCardQty += 1
                        cardQtyElem.innerHTML = deckCardQty
                    }

                    if (deckCardQty != 0) {
                        for (let myDeckCardElem of myDeckCardElems) {
                            if (myDeckCardElem.id == addCardBtn.id) {
                                // myDeckCardElem.style.display = "block"
                                myDeckCardElem.style.opacity = "100%"
                            }
                        }
                    }

                }

            }
        })
    }


    // Remove Cards from My Deck


    for (let removeCardBtn of removeCardBtns) {
        removeCardBtn.addEventListener("click", () => {

            for (let cardQtyElem of cardQtyElems) {
                if (cardQtyElem.id == removeCardBtn.id && cardQtyElem.classList.contains("my-inventory")) {

                    let inventoryCardQty = parseInt(cardQtyElem.innerHTML)

                    if (inventoryCardQty != 3) {
                        inventoryCardQty += 1
                        cardQtyElem.innerHTML = inventoryCardQty
                    }
                }
            }

            for (let cardQtyElem of cardQtyElems) {
                if (cardQtyElem.id == removeCardBtn.id && cardQtyElem.classList.contains("my-deck")) {
                    let deckCardQty = parseInt(cardQtyElem.innerHTML)

                    if (deckCardQty != 0) {
                        deckCardQty -= 1
                        cardQtyElem.innerHTML = deckCardQty
                    }

                    if (deckCardQty == 0) {
                        for (let myDeckCardElem of myDeckCardElems) {
                            if (myDeckCardElem.id == removeCardBtn.id)
                                // myDeckCardElem.style.display = "none"
                                myDeckCardElem.style.opacity = "30%"
                        }
                    }

                }

            }
        })
    }




    // Save the Deck 
    removeEventListenerFromSaveBtn()
    addEventListenerToSaveBtn()


    function removeEventListenerFromSaveBtn() {
        saveBtn.removeEventListener("click", saveDeck)
    }

    function addEventListenerToSaveBtn() {
        saveBtn.addEventListener("click", saveDeck)
    }

    function saveDeck() {
        for (let cardQtyElem of cardQtyElems) {
            if (cardQtyElem.classList.contains("my-deck")) {
                for (let deckCardBeingEdited of deckBeingEdited) { //deckcardbeingedited
                    let newQty = parseInt(cardQtyElem.innerHTML)
                    deckCardBeingEdited.card_in_deck_quantity = newQty
                    console.log("changed a record")
                }
            }
        }
        console.log("The deck after editing: ", deckBeingEdited)
    }


    // // Send the JSON data to Server
    // const res = await fetch('/deck/deckSaving', {
    //     method: 'POST',
    //     headers: {
    //         'Content-Type': 'application/json'
    //     },
    //     body: JSON.stringify(mockData)
    // })

    // if (res.ok) {
    //     console.log("saved successfully")
    //     console.log(res)
    // } else {
    //     console.log("fail to save")
    // }


}






createDeckBtn.addEventListener("click", async () => {
    let res = await fetch('/deck/createDeck', {
        method: 'GET'
    })
    if (res.ok) {
        alert("You have created a new deck!")
        deckMenuElem.innerHTML = ""
        loadDecks()
    } else {
        console.log("fail")
    }
})




